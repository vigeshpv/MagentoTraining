<?php
namespace Ceymox\Mymodule\ViewModel;

use Magento\Framework\View\Element\Block\ArgumentInterface;

Class Custom implements ArgumentInterface
{
	public function __construct()
	{

	}
	public function getSomething()
	{
		return "View Model tested";
	}
}
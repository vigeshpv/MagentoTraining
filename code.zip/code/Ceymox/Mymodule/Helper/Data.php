<?php

namespace Ceymox\Mymodule\Helper;
use \Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper
{
       
    public function getStoreConfig()
       {
           return "Welcome to world";
       }
}
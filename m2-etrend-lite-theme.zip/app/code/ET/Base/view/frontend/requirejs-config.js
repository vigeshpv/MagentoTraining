var config = {
    map: {
        '*': {
            baseowlcarousel: 'ET_Base/js/owl.carousel.min',
            basecountdowntimer: 'ET_Base/js/countdown-timer.min'
        }
    }
};
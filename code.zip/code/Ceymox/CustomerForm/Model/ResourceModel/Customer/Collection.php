<?php
namespace Ceymox\CustomerForm\Model\ResourceModel\Customer;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'customer_id';
	protected $_eventPrefix = 'customer_form_collection';
	protected $_eventObject = 'customer_collection';

	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct()
	{
		$this->_init('Ceymox\CustomerForm\Model\Customer', 
			'Ceymox\CustomerForm\Model\ResourceModel\Customer');
	}

}

<?php
namespace Ceymox\CustomerForm\Controller\Index;

Class ListData extends \Magento\Framework\App\Action\Action
{

	public function execute()

	{
		$this->_view->loadLayout();
		$this->_view->getLayout()->initMessages();
		$this->_view->renderLayout();
	}
}
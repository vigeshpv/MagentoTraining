<?php 
namespace CustomPage\AboutPage\Block;
Class Index extends \Magento\Framework\view\Element\Template
{
	
}